import pathlib
ROOT_DIR = pathlib.Path(__file__).parent.resolve()